/* Tyler Walsh
walsh_ao3b.js
19WI_INFO_2124_WW
Thoendel
12/20/2019 */

let preamble = "When in the course of human events"; //A variable with a string

console.log(`The preamble is:
    ${preamble}

Does the preamble contain 'a'?
    ${preamble.includes('a')}`); //A template literal that outputs the preamble, and checks if the preamble has an 'a' in it.